# Kaveri Infrasystems Pvt. Ltd. — Contract & Internal Policy Terms
### Contract: Smart Corridor Package 2 (SCP2) · Client: State Road Development Authority

Kaveri fabricates GI cable trays and CCTV poles in its own fabrication shop, then supplies,
installs and commissions them — together with optical fibre (OFC) laying — on government
infrastructure contracts. SCP2 is one such contract. Every rule below applies to the data pack.

---

## 1. Schedule and calendar

1.1 The master schedule is maintained in Primavera P6 and exported as `SCP2_schedule.xer`.

1.2 For SCP2 every calendar day is a working day of **8 hours**. Durations and lags in the XER
file are stored in **hours**, not days.

1.3 Reporting date for everything in this pack is **30 September 2026**.

## 2. Bill of Quantities (BOQ) and billing basis

2.1 Each BOQ item carries one billing basis (`boq.csv`, column `billing_basis`):

| Basis | Rule |
|---|---|
| PROGRESS | Billed monthly on the quantity **certified** by the client's Engineer-in-Charge in that period. |
| DELIVERY_QC | Billed on the quantity **dispatched to site in the month AND passed in-house QC**. Dispatched quantity that failed QC is never billable, even if it reached site. |
| MILESTONE | Billed **once, in full**, in the running-account (RA) bill for the month in which the linked milestone activity is completed. A milestone already billed is never billed again. |

2.2 **Disputed quantity** is excluded from the bill. It is carried forward and billed only after the
dispute is resolved and the quantity certified.

2.3 **Contract quantity cap.** Cumulative billed quantity for any item may never exceed its contract
quantity. Any certified quantity beyond the contract quantity is **not billed at the contract rate**;
it is recorded as a variation claim and pursued separately.

## 3. Running-account (RA) bill computation

Every RA bill is computed in exactly this order:

| Step | Line | Rule |
|---|---|---|
| 1 | Gross value of work | Sum of (billable quantity × BOQ rate) for the period |
| 2 | GST | 18% of gross value |
| 3 | Retention | 5% of gross value, deducted |
| 4 | Mobilisation advance recovery | See 3.1, deducted |
| 5 | **Net payable** | Gross + GST − Retention − Advance recovery |

3.1 A mobilisation advance of **8% of the contract value** was paid to Kaveri at contract start. It is
recovered at **10% of the gross value of each RA bill**, until the advance is fully recovered. A
recovery must never exceed the outstanding advance balance.

3.2 Bills RA-01 to RA-03 are in `bill_register.csv`. Cumulative quantities billed up to RA-03 are in
`cumulative_billed_to_RA03.csv`. The bill you must produce is **RA-04**, for work done in September 2026.

## 4. Payment terms and cash flow

4.1 The RA bill for work month M is submitted on the **5th of month M+1**. The client pays **30 days
after submission**.

4.2 Retention is released 12 months after commissioning — outside the forecast window.

4.3 **Forecast rule.** For cash-flow forecasting, the remaining quantity of each BOQ item is assumed to
be certified in full, with no disputes and no QC failures, in the month in which its linked WBS
activity is scheduled to finish.

## 5. Execution records, measurement and certification

5.1 Site engineers log daily progress in the execution log. Every execution record must link
**primarily to a WBS activity**, and through it to a BOQ item. Required drill-down:
**WBS activity → execution record → BOQ item.**

5.2 BOQ units govern. Site logs may be recorded in metres or kilometres.

5.3 Execution record status flow:
**Logged → Under Inspection → Inspection Certificate Received → Certified** (or **Disputed**).
A record may not be marked Certified unless an inspection certificate is attached.

5.4 Crew capacity for OFC laying is **400 m per crew per day**, with a maximum of **2 crews** on SCP2.
Any daily log exceeding site capacity must be flagged for verification, not accepted as recorded.

5.5 Any execution record whose WBS activity code does not exist in the master schedule must be flagged
for correction. It must never be silently re-mapped by the system.

## 6. Purchase approval policy

6.1 Purchase requests are approved by the level whose limit covers the value. Limits are **up to and
including** the stated amount (`approval_matrix.csv`). Routing starts at the **lowest** level whose
limit covers the value.

6.2 **Unavailability.** If the approver at that level is on leave on the request date (leave dates are
inclusive), the request routes to the **next level up**.

6.3 **Anti-splitting.** Purchase requests raised by the same requester, to the same vendor, on the same
date are **aggregated** to determine the approval level. Each request in the group routes to the level
the aggregate requires.

6.4 The Finance Head (L4) has no upper limit.

## 7. Fabrication shop

7.1 Standard steel consumption: GI cable tray 300 mm — **4.8 kg per metre**; CCTV pole 9 m —
**310 kg per pole**.

7.2 Steel issued above standard by **more than 5%** on any production order is flagged to the
Operations Head.

7.3 Items failing QC must be reworked or replaced. See 2.1 — they are never billable while failed.

## 8. Data handling

8.1 Management requires that contract values, rates and client data are not sent to any external AI
service. Any AI processing of this data **outside ClickUp** must run on a machine Kaveri controls.
